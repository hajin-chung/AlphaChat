gcc src/*.c src/*.h -o build/ac
./build/ac 239.0.1.100 5000