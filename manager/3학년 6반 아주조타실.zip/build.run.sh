gcc src/*.c src/*.h -o build/ac
./build/ac